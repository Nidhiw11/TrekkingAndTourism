 package com.example.trek_tour;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

 public class UploadProfilePic extends AppCompatActivity {
    private ProgressBar progressBar;
    private ImageView imageViewUploadPic;
    private FirebaseAuth authProfile;
    private StorageReference storageReference;
    private FirebaseUser firebaseUser;
    private static final int PICK_IMAGE_REQUEST=1;
    private Uri uriImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_profile_pic);

        getSupportActionBar().setTitle("Upload Profile Pic");

        Button buttonUploadPicChoose=findViewById(R.id.upload_Button);
        Button buttonUploadPic=findViewById(R.id.upload_pic_button);
        progressBar=findViewById(R.id.progress3);
        imageViewUploadPic=findViewById(R.id.imageView_Profile_dp);

        authProfile=FirebaseAuth.getInstance();
        firebaseUser=authProfile.getCurrentUser();
        storageReference= FirebaseStorage.getInstance().getReference("DisplayPics");
        Uri uri=firebaseUser.getPhotoUrl();

        //Set User's current DP in imageview(If uploaded already, picasso imageViewer)
        //Regular URI's
        Picasso.with(UploadProfilePic.this).load(uri).into(imageViewUploadPic);
        buttonUploadPicChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFileChooser();
            }
        });
    }
    private void openFileChooser(){
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

     @Override
     protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
         super.onActivityResult(requestCode, resultCode, data);

         if (requestCode==PICK_IMAGE_REQUEST && resultCode==RESULT_OK && data!=null && data.getData()!=null){
             uriImage=data.getData();
             imageViewUploadPic.setImageURI(uriImage);

         }

     }

     //Creating ActionBAr Menu
     public boolean onCreateOptionsMenu(Menu menu) {
         //Inflate menu items
         getMenuInflater().inflate(R.menu.common_menu,menu);
         return super.onCreateOptionsMenu(menu);
     }

     //When any menu item is selected
     @Override
     public boolean onOptionsItemSelected(@NonNull MenuItem item) {
         int id= item.getItemId();
         if(id==R.id.menu_refresh){
             //Refresh Activity
             startActivity(getIntent());
             finish();
             overridePendingTransition(0,0);
         }  else if (id == R.id.menu_user_profile) {
             Intent intent=new Intent(UploadProfilePic.this,UpdateProfile.class);
             startActivity(intent);
         } else if (id == R.id.menu_update_profile) {
             Intent  intent=new Intent(UploadProfilePic.this,UpdateProfile.class);
             startActivity(intent);
         }/*else if(id==R.id.menu_payment){
            Intent  intent=new Intent(DashB.this,payment.class);
            startActivity(intent);
        }else if(id==R.id.menu_settings){
            Toast.makeText(DashB.this, "menu_settings", Toast.LENGTH_SHORT).show();
        }else if(id==R.id.menu_DeleteProfile){
            Intent  intent=new Intent(DashB.this,DeleteProfile.class);
            startActivity(intent);
        }*/else if(id==R.id.menu_Logout){
             authProfile.signOut();
             Toast.makeText(UploadProfilePic.this, "Logged Out", Toast.LENGTH_SHORT).show();
             Intent intent=new Intent(UploadProfilePic.this,MainActivity.class);

             //Clear stack to prevent user coming back to DashBoard on back button after Logging out
             intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
             startActivity(intent);
             finish();//close DashBoard
         }else{
             Toast.makeText(UploadProfilePic.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
         }
         return super.onOptionsItemSelected(item);
     }
}