package com.example.trek_tour;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Karjat_details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karjat_details);
    }
}